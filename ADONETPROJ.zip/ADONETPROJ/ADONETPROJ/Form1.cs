﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADONETPROJ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Details button
        private void button1_Click(object sender, EventArgs e)
        {
            Details ob = new Details();
            ob.Show();
            this.Hide();
        }
        //Insert button
        private void button2_Click(object sender, EventArgs e)
        {
            InsertData ob = new InsertData();
            ob.Show();
            this.Hide();
        }
        //search button
        private void button4_Click(object sender, EventArgs e)
        {
            SearchForm ob = new SearchForm();
            ob.Show();
            this.Hide();
        }
        //DB DETAILS
        private void btndbdetails_Click(object sender, EventArgs e)
        {
            DbDetails ob = new DbDetails();
            ob.Show();
            this.Hide();
        }
    }
}
