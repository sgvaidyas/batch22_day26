﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADONETPROJ.Model;

namespace ADONETPROJ
{
    public partial class InsertData : Form
    {
        public InsertData()
        {
            InitializeComponent();
        }
        //SUBMIT BUTTON CODE
        private void btninsert_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            student.Name = txtName.Text;
            student.Email = txtEmail.Text;
            student.Phone = txtPhone.Text;
            student.Fees = float.Parse(txtFees.Text);
            student.Percent = float.Parse(txtPercent.Text);

            //MessageBox.Show(student.ToString());

            studentLogic ob = new studentLogic();
            string message = ob.AddData(student);
            MessageBox.Show(message);
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ob = new Form1();
            ob.Show();
        }
    }
}
