﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ADONETPROJ.Model
{
    class studentLogic
    {
        private string connStr = ConfigurationManager.ConnectionStrings["studb"].ConnectionString;

        public List<Student> getStudentDetails()
        {
            List<Student> li = new List<Student>();
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                string sql = "select * from Student";
                SqlCommand cmd = new SqlCommand(sql,conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while(reader.Read())
                {
                    Student s = new Student();
                    s.Id = Convert.ToInt32(reader.GetValue(0));
                    s.Name = reader.GetValue(1).ToString();
                    s.Email = reader.GetValue(2).ToString();
                    s.Phone = reader.GetValue(3).ToString();
                    s.Fees = float.Parse(reader.GetValue(0).ToString());
                    s.Percent = float.Parse(reader.GetValue(0).ToString());
                    li.Add(s);
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return li;
        }

        public string AddData(Student student)
        {
            string message = "";

            // string sql = " insert into Student(STUDENTNAME, EMAIL, PHONE, FEES,\"PERCENT\") values('";
            // sql += student.Name + "', ' " +student.Email+ "', '"+student.Phone +"', " + student.Fees +","+ student.Percent + ")";


            string sql = String.Format("insert into Student(STUDENTNAME, EMAIL, PHONE, FEES,\"PERCENT\") values('{0}','{1}','{2}',{3},{4})",student.Name,student.Email,student.Phone,student.Fees,student.Percent);

            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql,conn);
                cmd.ExecuteNonQuery();
                message = " the record inserted successfully : " + student.ToString();
            }
            catch(Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }
            return message;
        }

        public DataSet GetSearchData(int id)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from Student where Id="+id.ToString();

            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.Fill(ds);
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public DataSet getabledata()
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from sys.tables;select * from Student;select * from Staff";

            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
    }
}
